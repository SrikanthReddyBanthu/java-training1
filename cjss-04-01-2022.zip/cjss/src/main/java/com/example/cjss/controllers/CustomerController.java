package com.example.cjss.controllers;

import com.example.cjss.model.CustomerModel;
import com.example.cjss.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @RequestMapping(value = "/add-customer", method = RequestMethod.POST)
    public void add(@Valid @RequestBody CustomerModel customerModel) {
        customerService.add(customerModel);
    }

    @GetMapping("/get-customers")
    public List<CustomerModel> getAll() {
        return customerService.getAll();
    }

    @GetMapping("/get-customer/{id}")
    public CustomerModel getCustomer(@PathVariable Integer id) {
        return customerService.get(id);
    }

    @GetMapping("/get-customer/by-name/{name}")
    public List<CustomerModel> getCustomerByName(@PathVariable String name) {
        return customerService.getByName(name);
    }

    @GetMapping("/get-customer/by-designation/{designation}")
    public List<CustomerModel> getCustomerByDesignation(@PathVariable String designation) {
        return customerService.getByDesignation(designation);
    }

    @GetMapping("/get-customer/by-name-or-designation/{name}/{designation}")
    public List<CustomerModel> getCustomerByDesignation(@PathVariable String name,
                                                        @PathVariable String designation) {
        return customerService.getByNameOrDesignation(name, designation);
    }

    @DeleteMapping("/delete-customer/{id}")
    public void deleteCustomer(@PathVariable Integer id) {
        customerService.delete(id);
    }

}


/**
 * Tasks for 04  jan
 *
 * Try to update Customer fields (name and designation) for a given ID
 * @Query - Practice some customer SQL Queries using this annotation
 * For @Id field in entity try to add @GeneratedValue and practice using GeneratedValue
 * @EmbeddedId - Check what it is and how to use it
 */