package com.example.cjss.services;

import org.springframework.stereotype.Service;

@Service
public class CjssService {

    public String getMessage() {
        return "Welcome to CJSS!";
    }
}
