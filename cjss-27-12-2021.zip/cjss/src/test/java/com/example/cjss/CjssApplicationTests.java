package com.example.cjss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CjssApplicationTests {

	@Test
	void contextLoads() {
	}

}
