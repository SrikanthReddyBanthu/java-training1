package com.example.cjss.controllers;

import com.example.cjss.services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/add-employee/{id}/{name}")
    public void add(@PathVariable String id,
                             @PathVariable String name) {
        employeeService.add(id, name);
    }

    @GetMapping("/get-employees")
    public Map<String, String> getAll() {
        return employeeService.getAll();
    }

    @GetMapping("/get-employee/{id}")
    public String getEmployee(@PathVariable String id) {
        return employeeService.get(id);
    }

    @DeleteMapping("/delete-employee/{id}")
    public String deleteEmployee(@PathVariable String id) {
        return employeeService.delete(id);
    }

}
