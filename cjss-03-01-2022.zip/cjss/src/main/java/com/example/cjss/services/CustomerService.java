package com.example.cjss.services;

import com.example.cjss.entity.CustomerEntity;
import com.example.cjss.model.CustomerModel;
import com.example.cjss.model.EmployeeModel;
import com.example.cjss.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;


    public void add(CustomerModel customerModel) {
        
        CustomerEntity customerEntity = new CustomerEntity();
        customerEntity.setCustomerId(customerModel.getId());
        customerEntity.setDesignation(customerModel.getDesignation());
        customerEntity.setName(customerModel.getName());
        
        customerRepository.save(customerEntity);
    }

    public List<CustomerModel> getAll() {

        List<CustomerEntity> customDetails = customerRepository.findAll();
        return customDetails.stream()
                .map(customer -> getCustomerModel(customer))
                .collect(Collectors.toList());
    }

    public CustomerModel get(Integer id) {

        Optional<CustomerEntity> optionalCustomerEntity = customerRepository.findById(id);
        if (optionalCustomerEntity.isPresent()) {
            return getCustomerModel(optionalCustomerEntity.get());
        }
        return null;
    }

    public List<CustomerModel> getByName(String name) {

        List<CustomerEntity> customerEntity = customerRepository.findByName(name);
        return customerEntity.stream()
                .map(customer -> getCustomerModel(customer))
                .collect(Collectors.toList());
    }

    public List<CustomerModel> getByDesignation(String designation) {

        List<CustomerEntity> customerEntity = customerRepository.findByDesignation(designation);
        return customerEntity.stream()
                .map(customer -> getCustomerModel(customer))
                .collect(Collectors.toList());
    }

    public List<CustomerModel> getByNameOrDesignation(String name, String designation) {

        List<CustomerEntity> customerEntity = customerRepository.findByNameOrDesignation(name, designation);
        return customerEntity.stream()
                .map(customer -> getCustomerModel(customer))
                .collect(Collectors.toList());
    }

    public void delete(Integer id) {

        Optional<CustomerEntity> optionalCustomerEntity = customerRepository.findById(id);

        if (optionalCustomerEntity.isPresent()) {
            customerRepository.delete(optionalCustomerEntity.get());
        }

        //optionalCustomerEntity.ifPresent(customerEntity -> customerRepository.delete(customerEntity));
    }



    private CustomerModel getCustomerModel(CustomerEntity customerEntity) {
        return new CustomerModel(customerEntity.getCustomerId(), customerEntity.getName(), customerEntity.getDesignation());
    }


}
