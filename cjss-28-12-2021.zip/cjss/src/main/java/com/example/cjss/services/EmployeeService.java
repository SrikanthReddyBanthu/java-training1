package com.example.cjss.services;

import com.example.cjss.model.EmployeeModel;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EmployeeService {

    private List<EmployeeModel> employees = new ArrayList<>();

    public void add(EmployeeModel employee) {
        employees.add(employee);
    }

    public List<EmployeeModel> getAll() {
        return employees;
    }

    public EmployeeModel get(String id) {

        return employees.stream()
                .filter(employeeModel -> employeeModel.getId().equals(id)).findFirst().orElse(null);
    }

    public void delete(String id) {
        EmployeeModel employee = employees.stream()
                .filter(employeeModel -> employeeModel.getId().equals(id)).findFirst().orElse(null);
        employees.remove(employee);
    }

}
