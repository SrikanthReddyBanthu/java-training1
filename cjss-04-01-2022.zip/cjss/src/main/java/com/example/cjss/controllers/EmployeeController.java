package com.example.cjss.controllers;

import com.example.cjss.model.EmployeeModel;
import com.example.cjss.services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    /*@RequestMapping(value = "/add-employee", method = RequestMethod.POST)
    public void add(@RequestParam String id,
                             @RequestParam String name) {
        employeeService.add(id, name);
    }*/

    @RequestMapping(value = "/add-employee", method = RequestMethod.POST)
    public void add(@RequestBody EmployeeModel employeeModel) {
        employeeService.add(employeeModel);
    }

    @GetMapping("/get-employees")
    public List<EmployeeModel> getAll() {
        return employeeService.getAll();
    }

    @GetMapping("/get-employee/{id}")
    public EmployeeModel getEmployee(@PathVariable String id) {
        return employeeService.get(id);
    }

    @DeleteMapping("/delete-employee/{id}")
    public void deleteEmployee(@PathVariable String id) {
        employeeService.delete(id);
    }

}
