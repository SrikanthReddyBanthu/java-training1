package com.example.cjss.controllers;

import com.example.cjss.services.CjssService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CjssController {

    @Autowired
    private CjssService cjssService;

    @GetMapping("/get-message")
    public String getMessage() {
        return cjssService.getMessage();
    }


}
